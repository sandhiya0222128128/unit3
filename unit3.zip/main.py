def linearsearchproduct(produtlist,targetprodut):
  indices=[]
  for index,product in enumerate(produtlist):
    if product==targetprodut:
       indices.append(index)
  return indices
  #example usages
products=["shoes","boot","loafer","shoes","sandal","shoes"]
target="shoes"
result=linearsearchproduct(products,target)
print(result)